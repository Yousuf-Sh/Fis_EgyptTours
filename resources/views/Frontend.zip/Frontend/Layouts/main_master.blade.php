@include('Frontend.Layouts.head')
@include('Frontend.Layouts.header')


@yield('content')


@include('Frontend.Layouts.footer')
@include('Frontend.Layouts.script')    